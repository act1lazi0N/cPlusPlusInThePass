#include<bits/stdc++.h>
using namespace std;
int main()
{
    long long n,p,cnt=0;
    cin>>n>>p;
    while(n>1)
    {
        cnt=cnt+n/p;
        n=n/p;
    }
    cout<<cnt;
}
