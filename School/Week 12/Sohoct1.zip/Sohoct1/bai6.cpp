#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t,p,e;
    long long cnt=1;
    cin>>t;
    for(int i=0;i<t;i++)
    {
        cin>>p>>e;
        cnt=cnt*(e+1);
        cnt=cnt%(int)(1e9+7);
    }
    cout<<cnt;
}
