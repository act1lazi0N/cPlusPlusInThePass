#include<bits/stdc++.h>
using namespace std;
int prime[10000005];
void era()
{
    prime[0]=prime[1]=1;
    for(int i=2;i*i<=10000000;i++)
    {
        if(!prime[i])
        {
            for(int j=i*i;j<=10000000;j+=i)
                prime[j]=1;
        }
    }
}
bool check(int a)
{
    int sum=0;
    while(a!=0)
    {
        if(prime[a%10]==1)return false;
        sum=sum+a%10;
        a=a/10;
    }
    if(prime[sum]==1)return false;
    return true;
}
bool check1(int a)
{
    for(int i=2;i*i<=a;i++)
    {
        if(a%i==0)
            return false;
    }
    return true;
}
int main()
{

    int a,b,cnt=0;
    cin>>a>>b;
    era();
    for(int i=a;i<=b;i++)
    {
        if(i<(int)1e7)
        {
            if(!prime[i])
                {
                    if(check(i))
                    cnt++;
                }
        }
        else if(check1(i)&&check(i))
            cnt++;
    }
    cout<<cnt;
}
