#include<bits/stdc++.h>
using namespace std;
int prime[1000002];
vector<long long> a;
void era()
{
    prime[0]=prime[1]=1;
    for(int i=2;i*i<=1000002;i++)
        if(!prime[i])
            for(int j=i*i;j<=1000002;j+=i)
                prime[j]=1;
    for(int i=2;i<=1000000;i++)
        if(!prime[i])
            a.push_back(i);
}
int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    long long n;
    cin>>n;
    era();
    for(auto x:a)
    {
        if((x*x)<=n)
            cout<<x*x<<" ";
        else break;
    }
}
