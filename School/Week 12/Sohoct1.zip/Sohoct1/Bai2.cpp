#include<bits/stdc++.h>
using namespace std;
int prime[1000002];
vector<int>snt;
void era()
{
    prime[0]=prime[1]=1;
    for(int i=2;i*i<=1000002;i++)
    {
        if(!prime[i])
        {
            for(int j=i*i;j<=1000002;j+=i)
            {
                prime[j]=1;
            }
        }
    }
    for(int i=2;i<=1000002;i++)
        if(!prime[i])
            snt.push_back(i);
}
int main()
{
    int t,n;
    cin>>t;
    era();
    for(int i=0;i<t;i++)
    {
        cin>>n;
        for(auto x:snt)
        {
            if(x>n/2)break;
            if(x<n&&prime[n-x]==0)
                cout<<x<<" "<<n-x<<"\n";
        }
    }
}
