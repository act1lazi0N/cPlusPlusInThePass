#include<bits/stdc++.h>
using namespace std;
int prime[100002];
int n;
vector<int>a;
void era()
{
    prime[0]=prime[1]=1;
    for(int i=2;i*i<=n;i++)
    {
        if(!prime[i])
        {
            for(int j=i*i;j<=n;j+=i)
                prime[j]=1;
        }
    }
    for(int i=2;i<=n;i++)
        a.push_back(i);
}
int main()
{
    cin>>n;
    era();
    cout<<1<<"\n";
    for(int i=2;i<=n;i++)
    {
        if(i%2==0)
            cout<<2<<"\n";
        else if(prime[i]==0)
            cout<<i<<"\n";
        else
        {
            for(auto x:a)
                if(i%x==0)
                {
                    cout<<x<<"\n";
                    break;
                }
        }
    }
}
