#include<bits/stdc++.h>
using namespace std;
int prime[10000005],;
void era()
{
    prime[0]=prime[1]=1;
    for(int i=2;i*i<=10000000;i++)
    {
        if(!prime[i])
        {
            for(int j=i*i;j<=10000000;j+=i)
                prime[j]=1;
        }
    }
}
