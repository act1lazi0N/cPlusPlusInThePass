#include<bits/stdc++.h>
using namespace std;

void thang()
{
	float a, b, c, h, dh, s, r, pi = 3.14;
	cin >> a >> b >> c;
	dh = (b - a) / 2;
	h = sqrt(c * c - dh * dh);
	s = (a + b) * h / 2;
	r = h * 1 / 4;
	cout << setprecision(4) << s - (r * r * pi);

}
int main()
{
	thang();
	return 0;
}