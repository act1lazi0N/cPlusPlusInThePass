#include<bits/stdc++.h>
using namespace std;

void hand(int n)
{
	int a = 0;
	cin >> n;
	a = n * (n - 1) / 2;
	cout << a;
}
int main()
{
	hand('n');
	return 0;
}