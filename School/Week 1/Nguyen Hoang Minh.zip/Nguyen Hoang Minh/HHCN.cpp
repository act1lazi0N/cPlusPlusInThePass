#include<bits/stdc++.h>
using namespace std;

void hhcn()
{
	int a, b, h;

	cin >> a >> b >> h;
	int a1, a2, a3, s;
	a1 = sqrt(a * b / h);
	a2 = a / a1;
	a3 = b / a1;
	cout << 4 * a1 + 4 * a2 + 4 * a3;

}
int main()
{
	hhcn();
	return 0;
}