#include<bits/stdc++.h>
using namespace std;

void pheptinh()
{
	int a, b, c;
	cin >> a >> b >> c;
	cout << (a - b) * c << endl;
}
int main()
{
	pheptinh();
	return 0;
}
