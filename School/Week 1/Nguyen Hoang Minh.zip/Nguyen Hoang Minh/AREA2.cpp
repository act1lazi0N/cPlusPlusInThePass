#include<bits/stdc++.h>
using namespace std;

void tamgiac2()
{
	double a, h, s, r, s2, pi = 3.14;
	cin >> a;
	h = sqrt((a * a) - pow(a / 2, 2));
	r = a * sqrt(3) / 3;
	s = pi * r * r;
	s2 = (a * h) / 2;
	cout << fixed << setprecision(2) << s - s2 << endl;
}
int main()
{
	tamgiac2();
	return 0;
}