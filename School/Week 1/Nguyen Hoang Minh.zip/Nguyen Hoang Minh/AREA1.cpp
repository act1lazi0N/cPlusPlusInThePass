#include<bits/stdc++.h>
using namespace std;

void tamgiac1()
{
	double a, r, t, h;
	cin >> a;
	r = a * sqrt(3) / 6;
	t = 3.14 * pow(r, 2);
	h = sqrt(a * a - pow(a / 2, 2));
	cout << setprecision(3) << a * h / 2 - t;
}
int main()
{
	tamgiac1();
	return 0;
}