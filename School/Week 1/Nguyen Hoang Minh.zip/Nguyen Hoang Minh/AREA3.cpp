#include<bits/stdc++.h>
using namespace std;

void vuon()
{
	float a, b, c, s;
	cin >> a >> b >> c;
	s = (a * b) - ((b * c) + (a * c) - (c * c));
	cout << s << endl;
}
int main()
{
	vuon();
	return 0;
}