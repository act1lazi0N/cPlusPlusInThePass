#include<bits/stdc++.h>
using namespace std;

void baitap()
{
	float a, b;
	cin >> a >> b;
	cout << a + b << " " << a - b << " " << a * b << " " << a / b;

};
int main()
{
	baitap();
	return 0;

}