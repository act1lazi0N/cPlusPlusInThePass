#include<bits/stdc++.h>
using namespace std;

void tong()
{
	int a, b, c, d;
	cin >> a >> b >> c >> d;
	int T;
	T = a + b + c + d;
	
	cout << T << endl;
	cout << (T % 100)/10 << " " << (T % 100) % 10;

}
int main()
{
	tong();
	return 0;
}