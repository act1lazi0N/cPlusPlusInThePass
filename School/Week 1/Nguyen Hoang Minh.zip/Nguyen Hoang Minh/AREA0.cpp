#include<bits/stdc++.h>
using namespace std;

void dientich()
{
	float a, b;
	cin >> a >> b;
	float pi = 3.14;
	cout << a * b - pi * pow(a / 2, 2);
}
int main()
{
	dientich();
	return 0;
}