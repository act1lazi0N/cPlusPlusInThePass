#include<bits/stdc++.h>
using namespace std;

void noiquy()
{
	int a, b, c,
	int	t, n, m;
	cin >> a >> b >> c >> t >> n >> m;
	cout << (a * t) + (b * n) + (c * m) << endl;

}
int main()
{
	noiquy();
	return 0;
}