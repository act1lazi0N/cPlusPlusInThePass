#include<bits/stdc++.h>
using namespace std;

void gapdoi()
{
	int a;
	cin >> a;
	a = a * 2;
	cout << a << endl;
}
int main()
{
	gapdoi();
	return 0;
}