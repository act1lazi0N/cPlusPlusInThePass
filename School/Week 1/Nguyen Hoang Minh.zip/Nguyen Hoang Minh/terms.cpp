#include<bits/stdc++.h>
using namespace std;

void hang()
{
	int n, a = 0, b = 0;
	cin >> n;
	for (int i = n; i >= (n - 1) / 2; i--) {
		a += 1;

	};
	cout << a << endl;
	for (int i = n + 1; i <= n * n; i++) {
		b += 1;
	};
	cout << b << endl;
}
int main()
{
	hang();
	return 0;
}