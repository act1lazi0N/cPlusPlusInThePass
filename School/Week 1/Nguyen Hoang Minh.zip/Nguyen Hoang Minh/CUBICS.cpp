#include<bits/stdc++.h>
using namespace std;

void cube()
{
	int n, a = 0;
	cin >> n;
	for (int i = n; i <= n; i++) {
		a = ((n + 1) * n) / 2;
	};
	cout << a << endl;
}
int main()
{
	cube();
	return 0;
}