#include<bits/stdc++.h>
using namespace std;

void shoes(int n)
{
	cin >> n;
	if (n <= 100) {
		n += 1;
		cout << n << endl;
	}
	else {
		cout << "Eliminated!" << endl;
	}
}
int main()
{
	shoes('n');
	return 0;
}