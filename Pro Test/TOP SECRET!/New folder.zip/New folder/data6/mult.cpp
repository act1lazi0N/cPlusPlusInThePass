#include<bits/stdc++.h>
using namespace std;
int main(){
int a,b,c=0,d=0,t=0,e=0;
cin>>a>>b;
 while(a!=0)
{
    c=a%10;
    a/=10;
    t=b;
    while(t!=0)
   {
       d=t%10;
       t/=10;
       e+=c*d;
   }
}
cout<<e;
return 0;}
