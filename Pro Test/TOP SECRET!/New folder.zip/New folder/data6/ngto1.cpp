#include<bits/stdc++.h>
using namespace std;
bool snt (int n)
{
    if(n<=1)
        return false;
    for(int j=2; j<=sqrt(n); j++)
        if(n%j==0)return false;
    return true;
}
int main()
{
    int n,k;
    cin>>n;
    for(int i=1; i<=n; i++)
    {
        if(n%i==0)
        {
            k++;
        }



    }

     if(snt(k)==true)
        cout<<"YES";
        else
        cout<<"NO";




    return 0;
}
