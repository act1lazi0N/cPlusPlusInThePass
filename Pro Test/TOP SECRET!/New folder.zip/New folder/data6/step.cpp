#include<bits/stdc++.h>
using namespace std;
bool check(int n)
{
    int so = 0;
    if (n < 10)
        return false;
    else
    {
        while(n >= 10)
        {
            so = n % 10;
            n /=10;
            if (so <  (n % 10))
                return false;
        }

    }
    return true;
}
int main()
{
    int n;
    cin>>n;
    int a;
    for(int i=0; i<n; i++)
    {
        cin>>a;
        if(check(a)==true)
            cout<<"YES"<<endl;
        else
            cout<<"NO"<<endl;
    }
    return 0;
}
