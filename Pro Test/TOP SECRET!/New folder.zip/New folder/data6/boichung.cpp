#include<bits/stdc++.h>
using namespace std;
int main()
{
    int m,n,x,y,i=1;
    cin>>m>>n;
    x=m*n;
    y=m*n/__gcd(m,n);
    while(y*i<=x)
    {
        cout<<y*i<<" ";
        i++;
    }




    return 0;
}
