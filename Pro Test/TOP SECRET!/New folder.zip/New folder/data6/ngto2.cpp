#include<bits/stdc++.h>
using namespace std;
bool snt (int n)
{
    if(n<=1)
        return false;
    for(int j=2; j<=sqrt(n); j++)
        if(n%j==0)return false;
    return true;
}
int tong(int n)
  {
    int x;
    while(n>0){
    x=x+(n%10);
    n=n/10;}
    return x;
  }
int main(){

int a;
cin>>a;

if(snt(tong(a))==true)
cout<<"YES";
else
cout<<"NO";
return 0; }
