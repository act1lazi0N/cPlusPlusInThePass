#include<bits/stdc++.h>
using namespace std;
int ds (int n)
{
    int a=0;
    while(n!=0)
    {
        a=a*10+n%10;
        n=n/10;
    }
    return a;

}
int main()
{
    int n;
    cin>>n;
    if(n==ds(n))
    {
        cout<<n;
    }
    else
    {
        while(n!=ds(n))
        {
            n=n+ds(n);
        }

        cout<<n;
    }
    return 0;
}
