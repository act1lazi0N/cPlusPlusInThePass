#include<bits/stdc++.h>
using namespace std;
int main()
{
    int a,b,c;
    cin>>a>>b;
    while(__gcd(a,b)>1)
    {

        c=__gcd(a,b);
        a=a/c;
        b=b/c;
    }
    cout<<a<<"/"<<b;

    return 0;
}
