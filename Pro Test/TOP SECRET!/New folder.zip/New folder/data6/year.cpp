#include<bits/stdc++.h>
using namespace std;
 bool ss(int n)
 { int s1,s2,s3,s4;

     s1=n%10;
     s2=(n/10)%10;
     s3=(n/100)%10;
     s4=n/1000;
     if(s1==s2||s1==s3||s1==s4||s2==s3||s2==s4||s3==s4)
        return false;
    else
     return true;

 }
int main(){
    int n;
    cin>>n;
    for(int i=n+1;i<=9999;i++)
       {

         if(ss(i)==true)
           {cout<<i;
          return 0;}}




return 0;}
