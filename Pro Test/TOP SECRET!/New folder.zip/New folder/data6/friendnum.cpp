#include<bits/stdc++.h>
using namespace std;
int main()
{
    int a,b,c=0,d=0;
    cin>>a>>b;
    for(int i=1;i<a; i++)
    {
        if(a%i==0)
            c=c+i;}
    for(int j=1;j<b;j++)
    {

        if(b%j==0)
            d=d+j;
    }
    if((a==d)&&(b==c))
        cout<<"YES";
    else
        cout<<"NO";
    return 0;
}
