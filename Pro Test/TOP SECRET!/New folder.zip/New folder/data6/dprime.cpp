#include<bits/stdc++.h>
using namespace std;
bool snt (int n)
{
    if(n<=1)
        return false;
    for(int j=2; j<=sqrt(n); j++)
        if(n%j==0)return false;
    return true;
}
int tong(int n)
  {
    int x;
    while(n>0){
    x=x+(n%10);
    n=n/10;}
    return x;
  }
int main(){
int a[1001],n,dem=0,x,y,z,ans[1001],t=0;
    cin>>n;
    for(int i=0; i<n; i++)
        cin>>a[i];

    for(int i=0; i<n; i++)
    {
       if(snt(a[i])==true&&snt(tong(a[i]))==true)
        {
            dem++;
            ans[t++]=a[i];
        }
    }
     cout<<dem<<endl;
     for(int i=0;i<t-1;i++)
     {
         cout<<ans[i]<<" ";
     }
     cout<<ans[t-1];
return 0;
}
