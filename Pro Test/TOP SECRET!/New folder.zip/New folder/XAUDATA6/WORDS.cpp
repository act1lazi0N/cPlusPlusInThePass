#include<bits/stdc++.h>
using namespace std;
int main(){
    int dem=1;
    string s;
    getline(cin,s);
    for(int i=0;i<s.size();i++)
    {if(s[i]==' ')
      dem++;}
      cout<<dem;
      cout<<endl;
    for(int i=0;i<s.size();i++)
    {if(s[i]==' ')
    {s.erase(i,1);
      s.insert(i,"\n"); }}
    cout<<s;

    return 0;}
