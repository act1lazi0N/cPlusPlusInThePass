#include<bits/stdc++.h>
using namespace std;
int main(){
string s;
char x;
cin>>x;
fflush(stdin);
getline(cin,s);
int i=s.find(x);
while(i!=-1)
{
    s.erase(i,1);
    i=s.find(x);

}
cout<<s;




return 0;}
