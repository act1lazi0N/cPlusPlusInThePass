#include<bits/stdc++.h>
using namespace std;
int main()
{
    string s;
    getline(cin,s);
    int dem1=0,dem2=0,dem=0;
    for(int i=0; i<s.size(); i++)
    {
        if(s[i]!='('&&s[i]!=')')
        {
            cout<<"KHONG HOP LE";
            return 0;
        }

    }
    for(int i=0; i<s.size(); i++)
    {

        if(s[i]=='(')
            dem++;
        if(s[i]==')')
            dem--;
        if(dem<0)
        {
            cout<<"KHONG DUNG";
            return 0;
        }
    }
    for(int i=0; i<s.size(); i++)
    {

        if(s[i]=='(')
            dem1++;
        if(s[i]==')')
            dem2++;

    }
    if(dem1==dem2)
    {
        cout<<"DUNG";
    }

    else
    {
        cout<<"KHONG DUNG";
    }

    return 0;
}



