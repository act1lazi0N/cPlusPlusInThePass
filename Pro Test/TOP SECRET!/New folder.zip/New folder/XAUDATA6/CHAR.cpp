#include<bits/stdc++.h>
using namespace std;
int main()
{
    string s;
    int dem=0;
    getline(cin,s);
    while(s.size()!=0)
    {
        for(char i='a'; i<='z'; i++)
        {
            for(int j=0; j<s.size(); j++)
            {
                if(s[j]==i||s[j]==i-32)
                {
                    dem++;
                    s.erase(j,1);
                }
            }
            if(dem!=0)
            {
                cout<<i<<" "<<dem<<endl;
                dem=0;
            }
        }
    }
    return 0;
}
