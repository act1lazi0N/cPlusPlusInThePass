#include<bits/stdc++.h>
using namespace std;
int main(){
    int dem=0;
char x;
string s;
cin>>x;
fflush(stdin);
getline(cin,s);
for(int i=0;i<s.size();i++)
   {
    if(s[i]==x)
    dem++;}
    cout<<dem;
    cout<<endl;
for(int i=1;i<=s.size();i++)
   {
    if(s[i]==x)
cout<<i<<" ";}




return 0;}
