#include<iostream>
using namespace std;
int main()
{
    freopen("PARITY.INP","r",stdin);
    freopen("PARITY.OUT","w",stdout);
    int t;cin>>t;
    for(int i=0;i<t;i++)
    {
        cin>>n;

    }

}
