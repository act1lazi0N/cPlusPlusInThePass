#include<bits/stdc++.h>
using namespace std;

int n,a[100005];
vector<int,int>

int main()
{
    cin>>n;
}
