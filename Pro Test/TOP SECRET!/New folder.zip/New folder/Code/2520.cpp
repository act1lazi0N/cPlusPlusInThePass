#include<bits/stdc++.h>
using namespace std;
int main()
{
    long long h,r;cin>>h>>r;
    long long r0=sqrt((3*h*h)/4);
    cout<<(r-1)/r0;
}
