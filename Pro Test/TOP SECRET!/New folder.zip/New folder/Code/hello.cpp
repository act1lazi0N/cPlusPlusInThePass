#include<bits/stdc++.h>
using namespace std;
int main()
{
    int a=0;
    cout<<"hello world "<<a<<"jhkfg"
}
