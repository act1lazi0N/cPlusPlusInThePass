#include <bits/stdc++.h>
using namespace std;

string a,n;

int main()
{

}
