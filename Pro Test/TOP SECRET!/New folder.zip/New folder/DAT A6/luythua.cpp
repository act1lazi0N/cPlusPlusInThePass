#include<bits/stdc++.h>
using namespace std;
int main(){
int n,x,s;
cin>>x>>n;
s=pow(x,n);
cout<<s;



return 0;}

