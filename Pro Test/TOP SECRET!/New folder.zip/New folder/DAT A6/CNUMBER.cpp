#include<bits/stdc++.h>
using namespace std;
bool sodep(int n)
{
    while(n>0)
    {
        int t=n%10;
        if(t!=6&&t!=8)
        return false;
        n/=10;}
        return true;
}


int main()
{int n,dem=0;
cin>>n;
for(int i=1;i<=n;i++)
{if(sodep(i)==true)
    dem++;}
    cout<<dem;

return 0;
}
