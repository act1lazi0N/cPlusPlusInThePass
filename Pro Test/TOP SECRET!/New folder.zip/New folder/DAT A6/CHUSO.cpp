#include<bits/stdc++.h>
using namespace std;
int main(){
int n,sum=0,dem=0;
cin>>n;
for(int i=0;i<=n;i++)
{sum=sum+(n%10);
n=n/10;
dem++;
}
cout<<dem<<" "<<sum;

return 0;}
