#include<bits/stdc++.h>
using namespace std;
int main(){
int d,r;
cin>>d>>r;
for(int i=1;i<=d;i++) {
    for(int i=1;i<=r;i++) {
        cout<<"#";
    }
    cout << endl;

}







return 0;}

