#include<bits/stdc++.h>
using namespace std;
int main()
{
    long long int n,s=0;
    cin>>n;
    for(long i=1;i<n; i++)
    {
        if (n%i==0)
        {
            s+=i;
        }
    }
         if(s>n)
         cout<<"1";
         else
         cout<<"0";

    return 0;
}
