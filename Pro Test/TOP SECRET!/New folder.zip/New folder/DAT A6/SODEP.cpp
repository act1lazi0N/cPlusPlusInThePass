#include<bits/stdc++.h>
using namespace std;
bool sodep(int n)
{
    while(n>0)
    {
        int t=n%10;
        if(t!=6&&t!=8)
        return false;
        n/=10;}
        return true;
}


int main()
{int n;
cin>>n;
if(sodep(n)==true)
    cout<<"YES";
else cout<<"NO";
return 0;
}
