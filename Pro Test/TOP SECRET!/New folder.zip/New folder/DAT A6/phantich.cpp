#include<bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    int x, y;

    x = sqrt(n);
    cin >> n;
    if (x == sqrt(x))
    {
        y = x;
    }
    else
    {
        for (int i = x; i <= n; i--)
    {
        if (n % i == 0)
        {
            x = i;
            y = n / i;
            break;
        }
    }
    }
    cout << x << " " << y;





}
