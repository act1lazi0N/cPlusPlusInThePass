#include<bits/stdc++.h>
using namespace std;
int main(){
int n,m,dem;
cin>>n>>m;
for(int i=0;i<n;i++)
{n=n+n*10/100;
dem++;
if(m<=n)break;}
cout<<dem;

return 0;}
