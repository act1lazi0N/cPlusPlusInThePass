#include<bits/stdc++.h>
using namespace std;
int main()
{
    int x;
    cin>>x;
    for(int i=1; i<=x; i++)
    {
        for(int j=1; j<=x; j++)
        {
            if(i%2==1)
            {
                if(j%2==0)
                    cout<<"B";
                else cout<<"W";
            }
            else if(j%2!=0)
                cout<<"B";
            else cout<<"W";
        } ;
        cout<<endl;
    };
return 0;
}
