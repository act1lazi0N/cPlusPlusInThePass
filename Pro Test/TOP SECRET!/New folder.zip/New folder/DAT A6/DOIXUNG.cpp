#include<bits/stdc++.h>
using namespace std;
int main()
{
    long long n,r,i,tong=0;
    cin>>n;
    for(i=n; n!=0; n=n/10)
    {
        tong=tong*10+n%10;

    }
    if (tong==i)
        cout<<"YES";
    else cout<<"NO";




    return 0;
}
