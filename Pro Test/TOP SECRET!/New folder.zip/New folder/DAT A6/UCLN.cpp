#include<bits/stdc++.h>
using namespace std;
int main(){
long long n,m;
cin>>n>>m;
cout<<abs(__gcd(n,m));
return 0;}
