#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,sum,t;
cin>>n;
t=n;
for(int i=0;i<n;i++)
{while(t!=0)
{sum+=t%10;
t/=10;}
sum=sum/10+sum%10;

}


cout<<sum;

return 0;}
