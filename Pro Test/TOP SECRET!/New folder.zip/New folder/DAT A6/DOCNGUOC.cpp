#include<bits/stdc++.h>
using namespace std;
int main()
{
long long a,b,sw1,sw2,dao1=0,dao2=0;
cin>>a>>b;
while(a>0)
{sw1=a%10;
dao1=dao1*10+sw1;
a=a/10;}
while(b>0)
{sw2=b%10;
dao2=dao2*10+sw2;
b=b/10;}
if(dao1>dao2)
cout<<dao1;
else
cout<<dao2;
return 0;}
