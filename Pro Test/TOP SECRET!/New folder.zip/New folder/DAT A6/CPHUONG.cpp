#include<bits/stdc++.h>
using namespace std;

bool check(int n)
{
    int i = 0;
    if (n < 1)
        return false;
    while (i <= sqrt(n))
    {
        if (i == sqrt(n))
        return true;
    ++i;
    }
    return false;
}
int main()
{
    int n, dem = 0;
    cin >> n;
    for (int i = 0; i < n; i++)
    {
        if (check(i))
        {
            dem++;
        }
    }
    cout << dem << endl;
    for (int i = 0; i < n; i++)
    {
        if (check(i))
	    
            cout << " " << i;

    }
    return 0;
}
