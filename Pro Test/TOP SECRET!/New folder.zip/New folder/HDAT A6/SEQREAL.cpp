#include<bits/stdc++.h>
using namespace std;
int main()
{
    float n,a[101],s1=0,s2=0,s3=0,sc=0,sl=0;
    cin>>n;
    for(int i=0; i<n; i++)
    {
        cin>>a[i];
        s1=s1+a[i];
    }
    for(int i=0; i<n; i++)
    {

        if(a[i]<0)
        {
            s2=s2+a[i];
        }
        if(a[i]>0)
        {
            s3=s3+a[i];
        }
    }
    for(int i=0;i<n; i++)
    {
        if((i+1)%2==0)
        {
            sc=sc+a[i];
        }

        if((i+1)%2==1)
        {
            sl=sl+a[i];
        }
    }
    cout<<fixed <<setprecision(2)<<s1<<" "<<s2<<" "<<s3<<" "<<sc<<" "<<sl;

    return 0;
}
