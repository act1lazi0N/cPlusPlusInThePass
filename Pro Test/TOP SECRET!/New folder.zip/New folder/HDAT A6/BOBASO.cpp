#include<bits/stdc++.h>
using namespace std;
int main(){
int n,a[101];
cin>>n;
for(int i=0;i<n;i++)
cin>>a[i];
int dem=0,maxx=0;
for(int i=0;i<n-2;i++)
    for(int j=i+1;j<n-1;j++)
     for(int t=j+1;t<n;t++)
        {
            if(a[i]+a[j]>a[t]&&a[t]+a[i]>a[j]&&a[t]+a[j]>a[i])
                dem++;
             maxx=max(a[i]+a[j]+a[t],maxx);
        }
cout<<dem<<" "<<maxx;
return 0;}
