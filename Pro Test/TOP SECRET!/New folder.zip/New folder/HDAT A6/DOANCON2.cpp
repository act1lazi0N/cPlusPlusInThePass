#include<bits/stdc++.h>
int a[1000001],n,dem=1,maxx=-1e6+1;
using namespace std;
int main()
{

    cin>>n;
    cin>>a[0];
    for(int i=1; i<n; i++)
    {
        cin>>a[i];
        if(a[i]*a[i-1]<0)
            dem++;
        else
        {
            maxx=max(dem,maxx);
            dem=1;
        }
    }
   cout<<max(maxx,dem);
    return 0;
}
