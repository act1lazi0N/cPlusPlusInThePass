#include<bits/stdc++.h>
using namespace std;
bool snt (int n)
{
    if(n<=1)
        return false;
    for(int j=2; j<=sqrt(n); j++)
        if(n%j==0)return false;
    return true;
}
int main()
{
    int n,a[101],dem1=0,dem2=0;
    cin>>n;
    for(int i=1; i<=n; i++)
    {
        cin>>a[i];
        if(snt(a[i])==true)
        {
            dem2=dem2+a[i];
            dem1++;
        }
    }
    cout<<dem1<<" "<<dem2;
    return 0;
}
