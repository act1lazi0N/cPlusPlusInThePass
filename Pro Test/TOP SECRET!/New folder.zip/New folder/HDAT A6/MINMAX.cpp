#include<bits/stdc++.h>
using namespace std;
int main()
{
    float n,a[101],min,max;
    cin>>n;

    for(int i=0; i<n; i++)
        cin>>a[i];
    max=a[0];
    min=a[0];
    for(int i=0; i<n; i++)
    {
        if(max<a[i])
            max=a[i];
    }
    for(int i=0; i<n; i++)
    {

        if(min>a[i])
            min=a[i];
    }

    cout<<fixed<<setprecision(2)<<max<<" "<<min;

    return 0;
}
