#include<bits/stdc++.h>
using namespace std;
bool sodep (int n)
{
    while(n>0)
    {
        int t=n%10;
        if(t!=6&&t!=8)
            return false;
        n=n/10;
    }
    return true;
}
int main()
{
    int n,dem,a[101];
    cin>>n;
    for(int i=1; i<=n; i++)
    {
        cin>>a[i];
        if(sodep(a[i])==true)
            dem++;
    }
    cout<<dem;
    return 0;
}
